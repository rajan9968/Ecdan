<!DOCTYPE html>
<html lang="en">
<head>
  <title>Advocate</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- BOOTSTRAP -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
 
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- STYLESHEET -->
  <link rel="stylesheet" type="text/css" href="style.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
    integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g=="
    crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"
    integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw=="
    crossorigin="anonymous" />

</head>
<body>

	<!-- TOPHADER -->
	<section class="topheader">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
			    <a href="index.html"><img src="image/logo.png" class="img-fluid"></a>
		       </div>
		       <div class="col-md-9">
		       	<nav class="navbar navbar-expand-sm menu">
					  <div class="container-fluid">
					    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
					      <span class="navbar-toggler-icon"></span>
					    </button>
					    <div class="collapse navbar-collapse" id="collapsibleNavbar" style="justify-content: end;">
					     <ul class="navbar-nav">
					        <li class="nav-item">
					          <a class="nav-link" href="index.html">Home</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="advocate.html">Advocate</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="learn.html">Learn</a>
					        </li>
					         <li class="nav-item">
					          <a class="nav-link" href="connect.html">Connect</a>
					        </li>    
					         <li class="nav-item">
					          <a class="nav-link" href="connect2.html">Contact</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
					        </li>
					      </ul>
					    </div>
					  </div>
					</nav>
		       </div>
			</div>
		</div>
	</section>

	<section class="res" style="background: #1a4e8a;padding: 4%;">
		<div class="container">
			<div class="row">
				<div class="col-md-5 ">
					<img class="upb" src="image/06.png">
				</div>
				<div class="col-md-7">
					<h1>Advocate</h1>
					<p>With nearly million children across the globe in of quality childcare, it is time we
                       built more resilient childcare systems. Quality childcare services can:With nearly million children across the globe in of quality childcare, it is time we
                       built more resilient childcare systems. Quality childcare services can:</p>
				</div>
			
			</div>
		</div>
	</section>
	<section class="res2">
		<div class="container">
				<div class="row">
				<div class="col-md-6 my-4">
						<h1>Advocacy Resources</h1>	
						<p style="font-size:13px;">With nearly million children across the globe in of quality childcare, it is time we
                       built more resilient childcare systems. Quality childcare services can:</p>				
				</div>
				<div class="col-md-3 border1 my-4 text-center">
					
					<h3>social Media Toolkit</h3>	
					  <button type="button" style="width:134px;" class="btn btn-warning">Read More</button>
				</div>
				<div class="col-md-3 border1 my-4 text-center">
					<h3>Childcare Advocacy PPT</h3>
					  <button type="button" style="width:134px;" class="btn btn-warning">Read More</button>	
				</div>
			</div>	
		</div>
	</section>


<section class="py-4" id="courses">
  <div class="container">
    <h3 class="title py-2">Why Invest in Childcare?</h3>	
      <div class="row">
        <div class="col-sm-12">
          <div id="customers-testimonials" class="owl-carousel">

            <!--TESTIMONIAL 1 -->
            <div class="item">
              
                <div class="item-details">

                  <h4><i class="fa fa-user" aria-hidden="true"></i> <span></span></h4>
                  <p>
          High quality childcare in early years provides
a critical opportunity at the right time for
children to be in safe, healthy, stimulating
environment to learn, play, and grow,<br><br>
Children who participate in high-quality
childcare have improved developmental and
educational and better socio-economic
outcomes as adults.</p>
                </div>
              
            </div>
            <!--END OF TESTIMONIAL 1 -->
            <!--TESTIMONIAL 2 -->
            <div class="item">
              <div class="shadow-effect">
                <div class="item-details">
                 <h4><i class="fa fa-tasks" aria-hidden="true"></i> <span></span></h4>
                  <p>
          High quality childcare in early years provides
a critical opportunity at the right time for
children to be in safe, healthy, stimulating
environment to learn, play, and grow,<br><br>
Children who participate in high-quality
childcare have improved developmental and
educational and better socio-economic
outcomes as adults. </p>
                </div>
              </div>
            </div>
            <!--END OF TESTIMONIAL 2 -->
            <!--TESTIMONIAL 3 -->
            <div class="item">
              <div class="shadow-effect">
                <div class="item-details">
                  <h4>	<i class="fa fa-usd"></i> <span></span></h4>
                  <p>
         High quality childcare in early years provides
a critical opportunity at the right time for
children to be in safe, healthy, stimulating
environment to learn, play, and grow,<br><br>
Children who participate in high-quality
childcare have improved developmental and
educational and better socio-economic
outcomes as adults.</p>
                </div>
              </div>
            </div>
            <!--END OF TESTIMONIAL 3 -->
            <!--TESTIMONIAL 4 -->
          <!--   <div class="item">
              <div class="shadow-effect">
                <div class="item-details">
                  <h4>ECDAN <span></span></h4>
                  <p>
          High quality childcare in early years provides
a critical opportunity at the right time for
children to be in safe, healthy, stimulating
environment to learn, play, and grow,<br><br>
Children who participate in high-quality
childcare have improved developmental and
educational and better socio-economic
outcomes as adults.</p>
                </div>
              </div>
            </div> -->
            <!--END OF TESTIMONIAL 4 -->
            <!--TESTIMONIAL 5 -->
           <!--  <div class="item">
              <div class="shadow-effect">
                <div class="item-details">
                  <h5>Chicken for two Roasted <span>$21</span></h5>
                  <p>There was a time when Chinese food in this country meant (Americanized) Cantonese food.</p>
                </div>
              </div>
            </div> -->
            <!--END OF TESTIMONIAL 5 -->
          </div>
        </div>
      </div>
      </div>
</section>



	<section class="ad" style="background:lavender;padding: 20px;margin-top: -230px;padding-top: 10%;">
		<div class="container">
			<div class="row">
					<h6 class="title py-2">Key Messages and Evidence</h6>
				<div class="col-md-6">
					<div class="row">

						<div class="col-md-4">
							<img src="image/07.png">
						</div>
						<div class="col-md-8">
							<p style="font-size: 13px;">In 201 8, the International Labour Organisation
								(ILO) estimated there were 1 billion children
								under the age of 15—including 800 million children
								under six-in need of care globally and warned of a
								severe and unsustainable "childcare crisis" if not
								properly addressed,</p>
						</div>
					</div>
				</div>
					<div class="col-md-6">
					<div class="row">
						<div class="col-md-4">
							<img src="image/07.png">
						</div>
						<div class="col-md-8">
							<p style="font-size: 13px;">In 201 8, the International Labour Organisation
								(ILO) estimated there were 1 billion children
								under the age of 15—including 800 million children
								under six-in need of care globally and warned of a
								severe and unsustainable "childcare crisis" if not
								properly addressed,</p>
						</div>
					</div>
				</div>
					<div class="col-md-6">
					<div class="row">
						<div class="col-md-4">
							<img src="image/07.png">
						</div>
						<div class="col-md-8">
							<p style="font-size: 13px;">In 201 8, the International Labour Organisation
								(ILO) estimated there were 1 billion children
								under the age of 15—including 800 million children
								under six-in need of care globally and warned of a
								severe and unsustainable "childcare crisis" if not
								properly addressed,</p>
						</div>
					</div>
				</div>
					<div class="col-md-6">
					<div class="row">
						<div class="col-md-4">
							<img src="image/07.png">
						</div>
						<div class="col-md-8">
							<p style="font-size: 13px;">In 201 8, the International Labour Organisation
								(ILO) estimated there were 1 billion children
								under the age of 15—including 800 million children
								under six-in need of care globally and warned of a
								severe and unsustainable "childcare crisis" if not
								properly addressed,</p>
						</div>
					</div>
				</div>
					<div class="col-md-6">
					<div class="row">
						<div class="col-md-4">
							<img src="image/07.png">
						</div>
						<div class="col-md-8">
							<p style="font-size: 13px;">In 201 8, the International Labour Organisation
								(ILO) estimated there were 1 billion children
								under the age of 15—including 800 million children
								under six-in need of care globally and warned of a
								severe and unsustainable "childcare crisis" if not
								properly addressed,</p>
						</div>
					</div>
				</div>
					<div class="col-md-6">
					<div class="row">
						<div class="col-md-4">
							<img src="image/07.png">
						</div>
						<div class="col-md-8">
							<p style="font-size: 13px;">In 201 8, the International Labour Organisation
								(ILO) estimated there were 1 billion children
								under the age of 15—including 800 million children
								under six-in need of care globally and warned of a
								severe and unsustainable "childcare crisis" if not
								properly addressed,</p>
						</div>
					</div>
				</div>
					<div class="col-md-6">
					<div class="row">
						<div class="col-md-4">
							<img src="image/07.png">
						</div>
						<div class="col-md-8">
							<p style="font-size: 13px;">In 201 8, the International Labour Organisation
								(ILO) estimated there were 1 billion children
								under the age of 15—including 800 million children
								under six-in need of care globally and warned of a
								severe and unsustainable "childcare crisis" if not
								properly addressed,</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section>
		<div class="container">
			<div class="row" style="justify-content:center;">
				<h3 class="title py-2">Take Action</h3>
				<div class="col-md-5 image_mid mx-2 my-2">
				<!-- <img src="image/01.jpg" class="img-fluid"> -->
 				<h3>Download the full messaging
            framework from here</h3>
             <button type="button" style="width:134px;" class="btn btn-warning">Read More</button>
			</div>
			<div class="col-md-5 image_mid my-2">
				<!-- <img src="image/01.jpg" class="img-fluid"> -->
					<h3>Download the full messaging
            framework from here</h3>
             <button type="button" style="width:134px;" class="btn btn-warning">Read More</button>
			</div>
			</div>
		</div>
	</section>
<section class=" li">
 	<div class="container">
 			<div class="row">
			    		<div class="col-md-4">
			    			<p>Contact edanc</p>
			    		</div>
			    			<div class="col-md-4">
			    			<p>Login to ECD Connect</p>
			    		</div>
			    		<div class="col-md-4">
			    			 <div class='icon social fb'><i class='fa fa-facebook'></i></div>
			    			 <div class='icon social tw'><i class='fa fa-twitter'></i></div>
               <div class='icon social in'><i class='fa fa-linkedin'></i></div>
               <div class='icon social in'><i class='fa fa-youtube-play'></i></div>
			    		</div>
			    	</div>
 	</div>
 </section>
	<footer class="py-5">
		<div class="container">
			<div class="row py-2 fr" style="justify-content: space-between;">
				<div class="col-md-12">
					<img src="image/logo.png" class="img-fluid" style="max-width: 185px;">
				</div>
				<div class="col-md-2">
					
				
					<p class="footer_para">455 Massachusetts
						Avenue NW, Suite 1000,
						Washington, DC 20001
						<br>
						<br>
						Email: info@ocdan.org
						Phone: 202.822.0033
						Fax: 202.457.1466</p>
						<button style="width: 100%; font-size: 12px; color:#fff!important;" type="button" class="btn btn-primary">Login to ECD Connect</button>
				</div>


				<div class="col-md-2">
					<h6>EDC Knowledge Gateway</h6>
					<p>Themes<br>
					   Countries/Regions<br>
					   Submit a resourc</p>
				</div>

				<div class="col-md-2">
					<h6>Global ECD Calender</h6>
					<p>Submit a event</p>
				</div>
				<div class="col-md-2">
					<h6>Global ECD Calender</h6>
					<p>Submit a event</p>
				</div>
				<div class="col-md-3">
					<h6>About ECDAN</h6>
					<p>News<br>
					Blogs<br>
					Knowledge Follow</p>
				</div>
				<div class="col-md-12 text-center">
					<h6><small style="font-size:10px;font-weight: 600;">2022 ECDAN. All Rights I and Conditions I privacy policy</small></h6>
				</div>
			</div>
		</div>
	</footer><!-- 
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta.2/js/bootstrap.js'></script> -->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
 <!--Jquery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>
<!-- Owl Carousel -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<!-- custom JS code after importing jquery and owl -->

 <script type="text/javascript">
  jQuery(document).ready(function($) {
"use strict";
$('#customers-testimonials').owlCarousel( {
    loop: true,
    center: true,
    items: 3,
    margin: 30,
    autoplay: true,
    dots:true,
    nav:true,
    autoplayTimeout: 8500,
    smartSpeed: 1000,
    navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
    responsive: {
      0: {
        items: 1
      },
      768: {
        items: 2
      },
      1170: {
        items: 3
      }
    }
  });
});
</script>
</body>
</html>