<!DOCTYPE html>
<html lang="en">
<head>
  <title>Index</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- BOOTSTRAP -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- STYLESHEET -->
  <link rel="stylesheet" type="text/css" href="style.css">
  <!-- GOOGEL FONTS -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&family=Roboto:wght@100&family=Source+Sans+Pro:wght@300;400&display=swap" rel="stylesheet">

</head>
<body>

	<!-- TOPHADER -->
	<section class="topheader">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
			     <a href="index.html"><img src="image/logo.png" class="img-fluid"></a>
		       </div>
		       <div class="col-md-9">
		       	<nav class="navbar navbar-expand-sm menu">
					  <div class="container-fluid">
					    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
					      <span class="navbar-toggler-icon"></span>
					    </button>
					    <div class="collapse navbar-collapse" id="collapsibleNavbar" style="justify-content: end;">
					      <ul class="navbar-nav">
					        <li class="nav-item">
					          <a class="nav-link" href="index.html">Home</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="advocate.html">Advocate</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="learn.html">Learn</a>
					        </li>
					         <li class="nav-item">
					          <a class="nav-link" href="connect.html">Connect</a>
					        </li>    
					         <li class="nav-item">
					          <a class="nav-link" href="connect2.html">Contact</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
					        </li>
					      </ul>
					    </div>
					  </div>
					</nav>
		       </div>
			</div>
		</div>
	</section>

	<!-- TOPHEADER END -->

	<!-- SLIDER -->
	   <div id="carousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carousel" data-slide-to="0" class="active"></li>
          <li data-target="#carousel" data-slide-to="1"></li>
          <li data-target="#carousel" data-slide-to="2"></li>
        </ol>

        <div class="carousel-inner" role="listbox">

          <div class="carousel-item active image_banner" style="height: 87%; ">
            <div class="caption">
              <h1>#ChildCare4All</h1>
              <h2>Building the foundation for a better future</h2>
               <button type="button" style="padding: 10px 18px;" class="btn12 btn btn-warning">Join The Campagin</button>
            </div>
          </div>

          <div class="carousel-item image_banner" style="height: 87%; ">
            <div class="caption">
               <h1>#ChildCare4All</h1>
              <h2>Building the foundation for a better future</h2><br>
               <button type="button" style="padding: 10px 18px;" class="btn12 btn btn-warning">Join The Campagin</button>

             <!--  <a class="big-button" href="" title="">Create Project</a>
              <div class="clear"></div>
              <a class="view-demo" href="" title="">View Demo</a> -->
            </div>
          </div>
          
          <div class="carousel-item image_banner" style="height: 87%;  background-size: cover;">
            <div class="caption">
               <h1>#ChildCare4All</h1>
              <h2>Building the foundation for a better future</h2><br>
               <button type="button" style="padding: 10px 18px;" class="btn12 btn btn-warning">Join The Campagin</button>
            </div>
          </div>

        </div>
        
        <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>

      </div>
	<!-- SLIDER END -->

	<section class="py-5">
		<div class="container">
			<div class="row">
				<div class="col-md-5 text-end left_image">
					<img src="image/01.png" class="img-fluid">
				</div>
				<div class="col-md-7">
					<h3 class="title">Advocate</h3>
					<p class="para">With nearly million children across the globe in of quality childcare, it is time we
                       built more resilient childcare systems. Quality childcare services can:</p>
                       <div class="row">
                       	<div class="col-md-2">
                       		<div class="icon_circle">
                       			<i class="fa fa-user" aria-hidden="true"></i>
                       		</div> 
                       		<div class="title_circle">
                       			<p>Advance child development</p>
                       		</div>                      		
                       	</div>
                       	<div class="col-md-1"></div>
                       		<div class="col-md-2">
                       		<div class="icon_circle">
                       			<i class="fa fa-tasks" aria-hidden="true"></i>
                       		</div>
                       			<div class="title_circle">
                       			<p>Increase and improve	 women's employment</p>
                       		</div>                        		
                       	</div>
                       	<div class="col-md-1"></div>
                       		<div class="col-md-2">
                       		<div class="icon_circle">
                       			<i class="fa fa-usd"></i>
                       		</div> 
                       			<div class="title_circle">
                       			<p>Stimulate economic growth </p>
                       		</div>                     		
                       	</div>
                       	<p class="para">Through the Childcare for All campaign. ECDAN and our partners seek to increase
                           and political commitment, Share resources, and Connect partners so that every
                           child and family who needs it has access to affordable and quality childcare services.S</p>
                       </div>
                       <button type="button" class="btn btn-warning">Read More</button>

				</div>
			</div>
		</div>
	</section>


	<section>
		<div class="container">
			<div class="row">
				<div class="col-md-7 learn">
					<img src="image/dot.png">
					<h3 class="title" style="padding-left:34px;">Learn</h3>
					<p style="padding-left:34px;">Visit our resource hub to read and download reports, evidence, and
						advocacy tools for childcare,</p>
						<button style="color:#fff!important;margin-left: 34px;" type="button" class="btn btn-primary">Read More</button>
						
						<div class="col-md-12 text-end">
							<img src="image/dot.png">
						</div>
                      
				</div>
				<div class="col-md-5" style="padding: 0!important;">
					<img src="image/01.jpg" class="fs_b img-fluid" style="max-width: 113%;">
				</div>
			</div>
		</div>
	</section>

	<section class="py-3">
		<div class="container">

			<div class="row">
				<div class="col-md-12 fz">
						<h3 class="title" style="justify-content:space-between; display: flex;">Connect
			
						 <button type="button" class="btn btn-warning">View More</button></h3>
				</div>
			<div class="col-md-8 mi ">
				<div class="image_gr">
					<div class="overlay"></div>
				<!-- <img src="image/03.jpg" class="img-fluid"> -->
				<h6 class="over1"><b>Lorem ipsum dolor sit amet</b></h6>
					<p style="color: #fff;padding-left: 16px;font-size: 14px;
		">Though this campaign,we want to lift up the voices of parents and childcare providers.Share your story to help us advocate for childcare for all.</p>
			</div>
		</div>
			<div class="col-md-4 ">
				<div class="image_gr2">
					<h6 class="over2"><b>Lorem ipsum dolor sit amet</b></h6>
					<p style="color: #fff;padding-left: 16px;font-size: 14px;
		">Though this campaign,we want to lift up the voices of parents and childcare providers.Share your story to help us advocate for childcare for all.</p></div>
			<div class="image_gr3">
					<h6 class="over3"><b>Lorem ipsum dolor sit amet</b></h6>
					<p style="color: #fff;padding-left: 16px;font-size: 14px;
		">Though this campaign,we want to lift up the voices of parents and childcare providers.Share your story to help us advocate for childcare for all.</p></div>
			</div>
			
		
		</div>
	</section>

 <section class="share showcase">
 	<div class="container">
 		<div class="row">
 			<div class="col-md-12">
 				<div class="overlay">
			    <h4>Share Your Story</h4>
			    <p class="over">Though this campaign,we want to lift up the voices of parents and childcare providers.Share your story to help us advocate for childcare for all.</p>
			    <div class="last_over" style="margin-top: 13%;">
			    
			    </div>
			  </div>
 			</div>
 		</div>
 	</div>
 </section>
 <section class=" li">
 	<div class="container">
 			<div class="row">
			    		<div class="col-md-4">
			    			<p>Contact edanc</p>
			    		</div>
			    			<div class="col-md-4">
			    			<p>Login to ECD Connect</p>
			    		</div>
			    		<div class="col-md-4">
			    			 <div class='icon social fb'><i class='fa fa-facebook'></i></div>
			    			 <div class='icon social tw'><i class='fa fa-twitter'></i></div>
               <div class='icon social in'><i class='fa fa-linkedin'></i></div>
               <div class='icon social in'><i class='fa fa-youtube-play'></i></div>
			    		</div>
			    	</div>
 	</div>
 </section>
	<footer class="py-5">
		<div class="container">
			<div class="row py-2 fr" style="justify-content: space-between;">
				<div class="col-md-12">
					<img src="image/logo.png" class="img-fluid" style="max-width: 185px;">
				</div>
				<div class="col-md-2">
					
				
					<p class="footer_para">455 Massachusetts
						Avenue NW, Suite 1000,
						Washington, DC 20001
						<br>
						<br>
						Email: info@ocdan.org
						Phone: 202.822.0033
						Fax: 202.457.1466</p>
						<button style="width: 100%; font-size: 12px; color:#fff!important;" type="button" class="btn btn-primary">Login to ECD Connect</button>
				</div>


				<div class="col-md-2">
					<h6>EDC Knowledge Gateway</h6>
					<p>Themes<br>
					   Countries/Regions<br>
					   Submit a resourc</p>
				</div>

				<div class="col-md-2">
					<h6>Global ECD Calender</h6>
					<p>Submit a event</p>
				</div>
				<div class="col-md-2">
					<h6>Global ECD Calender</h6>
					<p>Submit a event</p>
				</div>
				<div class="col-md-3">
					<h6>About ECDAN</h6>
					<p>News<br>
					Blogs<br>
					Knowledge Follow</p>
				</div>
				<div class="col-md-12 text-center">
					<h6><small style="font-size:10px;font-weight: 600;">2022 ECDAN. All Rights I and Conditions I privacy policy</small></h6>
				</div>
			</div>
		</div>
	</footer>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta.2/js/bootstrap.js'></script>
</body>
</html>