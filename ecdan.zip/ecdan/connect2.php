<!DOCTYPE html>
<html lang="en">
<head>
  <title>Connect</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- BOOTSTRAP -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
 
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- STYLESHEET -->
  <link rel="stylesheet" type="text/css" href="style.css">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"
    integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g=="
    crossorigin="anonymous" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css"
    integrity="sha512-sMXtMNL1zRzolHYKEujM2AqCLUR9F2C4/05cdbxjjLSRvMQIciEPCQZo++nk7go3BtSuK9kfa/s+a4f4i5pLkw=="
    crossorigin="anonymous" />





</head>
<body>

	<!-- TOPHADER -->
	<section class="topheader">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
			     <a href="index.html"><img src="image/logo.png" class="img-fluid"></a>
		       </div>
		       <div class="col-md-9">
		       	<nav class="navbar navbar-expand-sm menu">
					  <div class="container-fluid">
					    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
					      <span class="navbar-toggler-icon"></span>
					    </button>
					    <div class="collapse navbar-collapse" id="collapsibleNavbar" style="justify-content: end;">
					     <ul class="navbar-nav">
					        <li class="nav-item">
					          <a class="nav-link" href="index.html">Home</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="advocate.html">Advocate</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="learn.html">Learn</a>
					        </li>
					         <li class="nav-item">
					          <a class="nav-link" href="connect.html">Connect</a>
					        </li>    
					         <li class="nav-item">
					          <a class="nav-link" href="connect2.html">Contact</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
					        </li>
					      </ul>
					    </div>
					  </div>
					</nav>
		       </div>
			</div>
		</div>
	</section>


<section>
	<div class="container">
	<div class="row">
		<div class="col-md-6 last_para">
			<p style="color:#f6b700;">Imprproves life outcomes of childcare</p>
			<h4 style="font-size: 14px; color: #fff;font-weight:600;">Lorem ipsum dolor sit amet Lorem ipsum dolor sit
amet Lorem ipsum dolor sit amet Lorem ipsum</h4>
			<p>Am an ECD teacher, One of the challenges faced are; expensive further special
needs courses or studies. I have much interest in studying more and
understanding special kids but have got difficulties in achieving that since all
further studies and knowledge is expensive to get for a better life onto those
kids. 2.1ack of cheap special needs resources in my country includive of the
therapys needed for improvement yet it's us that can make a change in them,
why make them so hard for a low earners parent to support her kid for
therapy. What I want policy markers to know is , there is a large number of
special needs kids now in the world Who urgently need our help, free
personals to help are available yet the studied courses for mastery are
expensive, can't something be done for them and for a greater generation to
come. What's most important to me as a caregiver is to impose a lovely
change and be the cause to a great improvement to any child in my
environment
Dorothy Nassali
Uganda</p>
			
		</div>
		<div class="col-md-6" style="padding:0!important;">
			<img src="image/11.jpg" class="img-fluid" style="height: 100%;">
		</div>
	</div>
</div>
</section>



<section class="py-4" id="courses">
  <div class="container">
    <h3 class="title py-3" >Partner Initiatives</h3>
      <div class="row">
        <div class="col-sm-12">
          <div id="customers-testimonials" class="owl-carousel">

            <!--TESTIMONIAL 1 -->
            <div class="item">

                <div class="item-details">
                		<img src="image/03.jpg">  
                  <!-- <h4>OPTIONAL SUBJECTS <span></span></h4> -->
                  <p>
           The best UPSC coaching  institute additionally offers special categories for covering History, Geography, social science and Public Administration, This course structure includes mock tests and evaluations excluding covering the course of study extensively.          </p>
                </div>
              
            </div>
            <!--END OF TESTIMONIAL 1 -->
            <!--TESTIMONIAL 2 -->
           <div class="item">

                <div class="item-details">
                		<img src="image/03.jpg">  
                  <!-- <h4>OPTIONAL SUBJECTS <span></span></h4> -->
                  <p>
           The best UPSC coaching  institute additionally offers special categories for covering History, Geography, social science and Public Administration, This course structure includes mock tests and evaluations excluding covering the course of study extensively.          </p>
                </div>
              
            </div>
            <!--END OF TESTIMONIAL 2 -->
            <!--TESTIMONIAL 3 -->
           <div class="item">

                <div class="item-details">
                		<img src="image/03.jpg">  
                  <!-- <h4>OPTIONAL SUBJECTS <span></span></h4> -->
                  <p>
           The best UPSC coaching  institute additionally offers special categories for covering History, Geography, social science and Public Administration, This course structure includes mock tests and evaluations excluding covering the course of study extensively.          </p>
                </div>
              
            </div>
            <!--END OF TESTIMONIAL 3 -->
            <!--TESTIMONIAL 4 -->
            <div class="item">

                <div class="item-details">
                		<img src="image/03.jpg">  
                  <!-- <h4>OPTIONAL SUBJECTS <span></span></h4> -->
                  <p>
           The best UPSC coaching  institute additionally offers special categories for covering History, Geography, social science and Public Administration, This course structure includes mock tests and evaluations excluding covering the course of study extensively.          </p>
                </div>
              
            </div>
            <!--END OF TESTIMONIAL 4 -->
            <!--TESTIMONIAL 5 -->
           <!--  <div class="item">
              <div class="shadow-effect">
                <div class="item-details">
                  <h5>Chicken for two Roasted <span>$21</span></h5>
                  <p>There was a time when Chinese food in this country meant (Americanized) Cantonese food.</p>
                </div>
              </div>
            </div> -->
            <!--END OF TESTIMONIAL 5 -->
          </div>
        </div>
      </div>
      </div>
</section>

<section class="">
	<div class="container">
		<div class="row">
			<div class="col-md-8 contact_from">
				<h2>Share Your Story</h2>
				<p>Through ECDAN's Global Childcare Campaign, we want to lift up the voices of childcare providers and
parents from every country and every community. Your stories and perspectives can help ECDAN and our
partners raise awareness, inform policy decisions, and advocate for stronger national childcare systems,</p>
<div class="row">
           <div class="col-6">
            <input class="effect-1" type="text" placeholder="Name">
              <span class="focus-border"></span>
          </div>
           <div class="col-6">
            <input class="effect-1" type="text" placeholder="Email">
              <span class="focus-border"></span>
          </div>
			</div>

			<div class="row">
				 <div class="col-6">
            <input class="effect-1" type="text" placeholder="Type of child care program">
              <span class="focus-border"></span>
          </div>
           <div class="col-6">
            <input class="effect-1" type="text" placeholder="Country">
              <span class="focus-border"></span>
          </div>
			</div>
			<div class="form-group">
  <label for="comment">Message.</label>
  <textarea style="background: transparent;" class="form-control" rows="5" id="comment"></textarea>
</div>
<br>
<div class="row">
	<div class="col-md-3">
<button type="file" style="color: #fff;width: 100%;" class="btn btn-warning">Choose File</button> <br>
</div>
<div class="col-md-9 text-end">
	<img src="image/10.png">
</div>
</div>

<div class="row">
	<div class="col-md-4">
		<h5>Disclamier:</h5>
		<p style="font-size: 10px;">We have your permission to utilize your words or
video on websites or social media and/or use then-I in
other public ways to build awareness for affordable,</p>
	</div>
	<div class="col-md-1" style="font-size: 10px;">
		<input type="radio">Yes
	</div>
	<div class="col-md-3" style="font-size: 10px;">
		<input type="radio">Yes,but please do notuse my name.
	</div>
	<div class="col-md-1" style="font-size: 10px;">
		<input type="radio">No
	</div>
	<div class="col-md-2 text-end">
		<button style="color: #fff;width: 100%;" class="btn btn-primary">Submit</button>
	</div>
</div>
		</div>
		<div class="col-md-4 last_imag" style="padding: 0!important;">
			<img src="image/09.png" style="height: 100%;">
		</div>
		</div>
	</div>
</section>



 <section class=" li">
 	<div class="container">
 			<div class="row">
			    		<div class="col-md-4">
			    			<p>Contact edanc</p>
			    		</div>
			    			<div class="col-md-4">
			    			<p>Login to ECD Connect</p>
			    		</div>
			    		<div class="col-md-4">
			    			 <div class='icon social fb'><i class='fa fa-facebook'></i></div>
			    			 <div class='icon social tw'><i class='fa fa-twitter'></i></div>
               <div class='icon social in'><i class='fa fa-linkedin'></i></div>
               <div class='icon social in'><i class='fa fa-youtube-play'></i></div>
			    		</div>
			    	</div>
 	</div>
 </section>
	<footer class="py-5">
		<div class="container">
			<div class="row py-2 fr" style="justify-content: space-between;">
				<div class="col-md-12">
					<img src="image/logo.png" class="img-fluid" style="max-width: 185px;">
				</div>
				<div class="col-md-2">
					
				
					<p class="footer_para">455 Massachusetts
						Avenue NW, Suite 1000,
						Washington, DC 20001
						<br>
						<br>
						Email: info@ocdan.org
						Phone: 202.822.0033
						Fax: 202.457.1466</p>
						<button style="width: 100%; font-size: 12px; color:#fff!important;" type="button" class="btn btn-primary">Login to ECD Connect</button>
				</div>


				<div class="col-md-2">
					<h6>EDC Knowledge Gateway</h6>
					<p>Themes<br>
					   Countries/Regions<br>
					   Submit a resourc</p>
				</div>

				<div class="col-md-2">
					<h6>Global ECD Calender</h6>
					<p>Submit a event</p>
				</div>
				<div class="col-md-2">
					<h6>Global ECD Calender</h6>
					<p>Submit a event</p>
				</div>
				<div class="col-md-3">
					<h6>About ECDAN</h6>
					<p>News<br>
					Blogs<br>
					Knowledge Follow</p>
				</div>
				<div class="col-md-12 text-center">
					<h6><small style="font-size:10px;font-weight: 600;">2022 ECDAN. All Rights I and Conditions I privacy policy</small></h6>
				</div>
			</div>
		</div>
	</footer>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
 <!--Jquery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>
<!-- Owl Carousel -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<!-- custom JS code after importing jquery and owl -->

 <script type="text/javascript">
  jQuery(document).ready(function($) {
"use strict";
$('#customers-testimonials').owlCarousel( {
    loop: true,
    center: true,
    items: 3,
    margin: 30,
    autoplay: true,
    dots:true,
    nav:true,
    autoplayTimeout: 8500,
    smartSpeed: 1000,
    navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
    responsive: {
      0: {
        items: 1
      },
      768: {
        items: 2
      },
      1170: {
        items: 3
      }
    }
  });
});
</script>
</body>
</html>