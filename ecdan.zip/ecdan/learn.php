<!DOCTYPE html>
<html lang="en">
<head>
  <title>Learn</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- BOOTSTRAP -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- FONT AWESOME -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- STYLESHEET -->
  <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>

	<!-- TOPHADER -->
	<section class="topheader">
		<div class="container">
			<div class="row">
				<div class="col-md-3">
			   <a href="index.html"><img src="image/logo.png" class="img-fluid"></a>
		       </div>
		       <div class="col-md-9">
		       	<nav class="navbar navbar-expand-sm menu">
					  <div class="container-fluid">
					    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
					      <span class="navbar-toggler-icon"></span>
					    </button>
					    <div class="collapse navbar-collapse" id="collapsibleNavbar" style="justify-content: end;">
					     <ul class="navbar-nav">
					        <li class="nav-item">
					          <a class="nav-link" href="index.html">Home</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="advocate.html">Advocate</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="learn.html">Learn</a>
					        </li>
					         <li class="nav-item">
					          <a class="nav-link" href="connect.html">Connect</a>
					        </li>    
					         <li class="nav-item">
					          <a class="nav-link" href="connect2.html">Contact</a>
					        </li>
					        <li class="nav-item">
					          <a class="nav-link" href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
					        </li>
					      </ul>
					    </div>
					  </div>
					</nav>
		       </div>
			</div>
		</div>
	</section>

	<section>
		<div class="image_banner" style="padding:15% ; text-align: center; color: #fff; font-size: 20px;">
			<h3 style="font-size:40px;">Welcom o the</h3>
			<h1 style="font-size:45px;">Campaign Resource Aub</h1>
		</div>
	</section>

	<section class="py-5">
		<div class="container">
			<div class="row">
				<div class="col-md-4"></div>
				<div class="col-md-8 py-2">
					 <div class="input-group">
    <input type="text" class="form-control" placeholder="Search">
    <div class="input-group-btn">
      <button class="btn btn-default" type="submit">
        <i class="fa fa-search" aria-hidden="true"></i>
      </button>
    </div>
  </div>
					</div>
				<div class="col-md-4 gc" style="box-shadow: 0 0px 25px rgba(0, 0, 0, .2); padding:2%; border-radius: 1%; ">
					<h5>Global Childcare Landscape: Evidence and Policy</h5>
					<hr>
					<h5>Global Childcare Landscape: Evidence and Policy</h5>
					<hr>
					<h5>Global Childcare Landscape: Evidence and Policy</h5>
					<hr>
					<h5>Global Childcare Landscape: Evidence and Policy</h5>
					<hr>
					<h5>Global Childcare Landscape: Evidence and Policy</h5>
					<hr>
					<h5>Global Childcare Landscape: Evidence and Policy</h5>
				</div>
				
				<div class="col-md-8">

					<div class="col mx-auto my-auto">
  <div class="card msgcard">
    <div class="card-body">
      <div class="container-fluid">
        <div id="messages_container" class="chat-log">
          <div class="chat-log_item chat-log_item-own z-depth-0">
            <div class="row  mx-1 d-flex">
              <div class="col-auto px-0">
               
              </div>
              <div class="col-auto px-0">
              </div>
            </div>
          
            <div class="chat-log_message">
              <h5 style="text-align: left;color: #f6b700;font-weight: 600;">Better Jobs and Brighter Futures:<br>
                  Investing in Childcare to Build Human Capital</h5>
            </div>
             <hr class="my-4 py-0 col-12" style="opacity: 0.5">
           
          </div>
                   <div class="chat-log_item chat-log_item-own z-depth-0">
            <div class="row  mx-1 d-flex">
              <div class="col-auto px-0">
               
              </div>
              <div class="col-auto px-0">
              </div>
            </div>
          
            <div class="chat-log_message">
              <h5 style="text-align: left;color: #1a4e8a;font-weight: 600;">Better Jobs and Brighter Futures:<br>
                  Investing in Childcare to Build Human Capital</h5>
            </div>
             <hr class="my-4 py-0 col-12" style="opacity: 0.5">
           
          </div>
                    <div class="chat-log_item chat-log_item-own z-depth-0">
            <div class="row  mx-1 d-flex">
              <div class="col-auto px-0">
               
              </div>
              <div class="col-auto px-0">
              </div>
            </div>
          
            <div class="chat-log_message">
              <h5 style="text-align: left;color: #f6b700;font-weight: 600;">Better Jobs and Brighter Futures:<br>
                  Investing in Childcare to Build Human Capital</h5>
            </div>
             <hr class="my-4 py-0 col-12" style="opacity: 0.5">
           
          </div>
                   <div class="chat-log_item chat-log_item-own z-depth-0">
            <div class="row  mx-1 d-flex">
              <div class="col-auto px-0">
               
              </div>
              <div class="col-auto px-0">
              </div>
            </div>
          
            <div class="chat-log_message">
              <h5 style="text-align: left;color: #f6b700;font-weight: 600;">Better Jobs and Brighter Futures:<br>
                  Investing in Childcare to Build Human Capital</h5>
            </div>
             <hr class="my-4 py-0 col-12" style="opacity: 0.5">
           
          </div>
                    <div class="chat-log_item chat-log_item-own z-depth-0">
            <div class="row  mx-1 d-flex">
              <div class="col-auto px-0">
               
              </div>
              <div class="col-auto px-0">
              </div>
            </div>
          
            <div class="chat-log_message">
              <h5 style="text-align: left;color: #f6b700;font-weight: 600;">Better Jobs and Brighter Futures:<br>
                  Investing in Childcare to Build Human Capital</h5>
            </div>
             <hr class="my-4 py-0 col-12" style="opacity: 0.5">
           
          </div>
                    <div class="chat-log_item chat-log_item-own z-depth-0">
            <div class="row  mx-1 d-flex">
              <div class="col-auto px-0">
               
              </div>
              <div class="col-auto px-0">
              </div>
            </div>
          
            <div class="chat-log_message">
              <h5 style="text-align: left;color: #f6b700;font-weight: 600;">Better Jobs and Brighter Futures:<br>
                  Investing in Childcare to Build Human Capital</h5>
            </div>
             <hr class="my-4 py-0 col-12" style="opacity: 0.5">
           
          </div>
                   <div class="chat-log_item chat-log_item-own z-depth-0">
            <div class="row  mx-1 d-flex">
              <div class="col-auto px-0">
               
              </div>
              <div class="col-auto px-0">
              </div>
            </div>
          
            <div class="chat-log_message">
              <h5 style="text-align: left;color: #f6b700;font-weight: 600;">Better Jobs and Brighter Futures:<br>
                  Investing in Childcare to Build Human Capital</h5>
            </div>
             <hr class="my-4 py-0 col-12" style="opacity: 0.5">
           
          </div>
        </div>
      </div>
    </div>
  
  </div>
</div>
				</div>
			</div>
		</div>
	</section>

<section>
		<div class="container">
			<div class="row" style="justify-content:center;">
				<h3 class="title py-2">Take Action</h3>
				<div class="col-md-5 image_mid mx-2 my-2">
				<!-- <img src="image/01.jpg" class="img-fluid"> -->
 				<h3>Download the full messaging
            framework from here</h3>
             <button type="button" style="width:134px;" class="btn btn-warning">Read More</button>
			</div>
			<div class="col-md-5 image_mid my-2">
				<!-- <img src="image/01.jpg" class="img-fluid"> -->
					<h3>Download the full messaging
            framework from here</h3>
             <button type="button" style="width:134px;" class="btn btn-warning">Read More</button>
			</div>
			</div>
		</div>
	</section>

	<section class=" li">
 	<div class="container">
 			<div class="row">
			    		<div class="col-md-4">
			    			<p>Contact edanc</p>
			    		</div>
			    			<div class="col-md-4">
			    			<p>Login to ECD Connect</p>
			    		</div>
			    		<div class="col-md-4">
			    			 <div class='icon social fb'><i class='fa fa-facebook'></i></div>
			    			 <div class='icon social tw'><i class='fa fa-twitter'></i></div>
               <div class='icon social in'><i class='fa fa-linkedin'></i></div>
               <div class='icon social in'><i class='fa fa-youtube-play'></i></div>
			    		</div>
			    	</div>
 	</div>
 </section>
	<footer class="py-5">
		<div class="container">
			<div class="row py-2 fr" style="justify-content: space-between;">
				<div class="col-md-12">
					<img src="image/logo.png" class="img-fluid" style="max-width: 185px;">
				</div>
				<div class="col-md-2">
					
				
					<p class="footer_para">455 Massachusetts
						Avenue NW, Suite 1000,
						Washington, DC 20001
						<br>
						<br>
						Email: info@ocdan.org
						Phone: 202.822.0033
						Fax: 202.457.1466</p>
						<button style="width: 100%; font-size: 12px; color:#fff!important;" type="button" class="btn btn-primary">Login to ECD Connect</button>
				</div>


				<div class="col-md-2">
					<h6>EDC Knowledge Gateway</h6>
					<p>Themes<br>
					   Countries/Regions<br>
					   Submit a resourc</p>
				</div>

				<div class="col-md-2">
					<h6>Global ECD Calender</h6>
					<p>Submit a event</p>
				</div>
				<div class="col-md-2">
					<h6>Global ECD Calender</h6>
					<p>Submit a event</p>
				</div>
				<div class="col-md-3">
					<h6>About ECDAN</h6>
					<p>News<br>
					Blogs<br>
					Knowledge Follow</p>
				</div>
				<div class="col-md-12 text-center">
					<h6><small style="font-size:10px;font-weight: 600;">2022 ECDAN. All Rights I and Conditions I privacy policy</small></h6>
				</div>
			</div>
		</div>
	</footer>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta.2/js/bootstrap.js'></script>
</body>
</html>		